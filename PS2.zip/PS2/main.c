#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <getopt.h>
#include <stdlib.h>
#include <time.h>
#include "libs/bitmap.h"
#include <mpi.h>

int size; //Declaring global variable for MPI_SIZE
int rank; //Declaring global variable for MPI_SIZE

// Convolutional Kernel Examples, each with dimension 3,
// gaussian kernel with dimension 5

int sobelYKernel[] = {-1, -2, -1,
                       0,  0,  0,
                       1,  2,  1};

int sobelXKernel[] = {-1, -0, 1,
                      -2,  0, 2,
                      -1,  0, 1};

int laplacian1Kernel[] = { -1,  -4,  -1,
                           -4,  20,  -4,
                           -1,  -4,  -1};

int laplacian2Kernel[] = { 0,  1,  0,
                           1, -4,  1,
                           0,  1,  0};

int laplacian3Kernel[] = { -1,  -1,  -1,
                           -1,   8,  -1,
                           -1,  -1,  -1};

int gaussianKernel[] = { 1,  4,  6,  4, 1,
                         4, 16, 24, 16, 4,
                         6, 24, 36, 24, 6,
                         4, 16, 24, 16, 4,
                         1,  4,  6,  4, 1 };

char* const kernelNames[]       = { "SobelY",     "SobelX",     "Laplacian 1",    "Laplacian 2",    "Laplacian 3",    "Gaussian"     };
int* const kernels[]            = { sobelYKernel, sobelXKernel, laplacian1Kernel, laplacian2Kernel, laplacian3Kernel, gaussianKernel };
unsigned int const kernelDims[] = { 3,            3,            3,                3,                3,                5              };
float const kernelFactors[]     = { 1.0,          1.0,          1.0,              1.0,              1.0,              1.0 / 256.0    };

int const maxKernelIndex = sizeof(kernelDims) / sizeof(unsigned int);


// Helper function to swap bmpImageChannel pointers

void swapImage(bmpImage **one, bmpImage **two) {
  bmpImage *helper = *two;
  *two = *one;
  *one = helper;
}

// Apply convolutional kernel on image data
void applyKernel(pixel **out, pixel **in, unsigned int width, unsigned int height, int *kernel, unsigned int kernelDim, float kernelFactor) {
  unsigned int const kernelCenter = (kernelDim / 2);
  for (unsigned int y = 0; y < height; y++) {
    for (unsigned int x = 0; x < width; x++) {
      unsigned int ar = 0, ag = 0, ab = 0;
      for (unsigned int ky = 0; ky < kernelDim; ky++) {
        int nky = kernelDim - 1 - ky;
        for (unsigned int kx = 0; kx < kernelDim; kx++) {
          int nkx = kernelDim - 1 - kx;
          int yy = y + (ky - kernelCenter);
          int xx = x + (kx - kernelCenter);
          if (xx >= 0 && xx < (int) width && yy >=0 && yy < (int) height) {
            ar += in[yy][xx].r * kernel[nky * kernelDim + nkx];
            ag += in[yy][xx].g * kernel[nky * kernelDim + nkx];
            ab += in[yy][xx].b * kernel[nky * kernelDim + nkx];
          }
        }
      }
      if (ar || ag || ab) {
        ar *= kernelFactor;
        ag *= kernelFactor;
        ab *= kernelFactor;
        out[y][x].r = (ar > 255) ? 255 : ar;
        out[y][x].g = (ag > 255) ? 255 : ag;
        out[y][x].b = (ab > 255) ? 255 : ab;
      } else {
        out[y][x].r = 0;
        out[y][x].g = 0;
        out[y][x].b = 0;
      }
    }
  }
}

// This function does as applyKernel, but on a single list of pixels instead of a matrix of pixels. Furthermore it accesses data from boundary rows but only writes out new values for the local rows.
void applyKernelReplica(pixel *out, pixel *upper_bound, pixel *local_rows, pixel *lower_bound, unsigned int width, int *kernel, unsigned int kernelDim, float kernelFactor, int height) {
    unsigned int const kernelCenter = (kernelDim / 2);
    for (unsigned int y = 0; y < height; y++) {
        for (unsigned int x = 0; x < width; x++) {
            unsigned int ar = 0, ag = 0, ab = 0;
            for (unsigned int ky = 0; ky < kernelDim; ky++) {
                int nky = kernelDim - 1 - ky;
                for (unsigned int kx = 0; kx < kernelDim; kx++) {
                    int nkx = kernelDim - 1 - kx;
                    int yy = y + (ky - kernelCenter);
                    int xx = x + (kx - kernelCenter);
                    if(xx >= 0 && xx < (int) width) {
                        if (yy >=0 && yy < (int) height) {
                            ar += local_rows[yy*width + xx].r * kernel[nky * kernelDim + nkx];
                            ag += local_rows[yy*width + xx].g * kernel[nky * kernelDim + nkx];
                            ab += local_rows[yy*width + xx].b * kernel[nky * kernelDim + nkx];
                        } else if(yy < 0) {
                            ar += upper_bound[(kernelCenter+yy)*width + xx].r * kernel[nky * kernelDim + nkx];
                            ag += upper_bound[(kernelCenter+yy)*width + xx].g * kernel[nky * kernelDim + nkx];
                            ab += upper_bound[(kernelCenter+yy)*width + xx].b * kernel[nky * kernelDim + nkx];
                        } else {
                            ar += lower_bound[(yy-height)*width + xx].r * kernel[nky * kernelDim + nkx];
                            ag += lower_bound[(yy-height)*width + xx].g * kernel[nky * kernelDim + nkx];
                            ab += lower_bound[(yy-height)*width + xx].b * kernel[nky * kernelDim + nkx];
                        }
                    }
                }
            }
            if (ar || ag || ab) {
                ar *= kernelFactor;
                ag *= kernelFactor;
                ab *= kernelFactor;
                out[y*width + x].r = (ar > 255) ? 255 : ar;
                out[y*width + x].g = (ag > 255) ? 255 : ag;
                out[y*width + x].b = (ab > 255) ? 255 : ab;
            } else {
                out[y*width + x].r = 0;
                out[y*width + x].g = 0;
                out[y*width + x].b = 0;
            }
        }
    }
}


void help(char const *exec, char const opt, char const *optarg) {
    FILE *out = stdout;
    if (opt != 0) {
        out = stderr;
        if (optarg) {
            fprintf(out, "Invalid parameter - %c %s\n", opt, optarg);
        } else {
            fprintf(out, "Invalid parameter - %c\n", opt);
        }
    }
    fprintf(out, "%s [options] <input-bmp> <output-bmp>\n", exec);
    fprintf(out, "\n");
    fprintf(out, "Options:\n");
    fprintf(out, "  -k, --kernel     <kernel>        kernel index (0<=x<=%u) (2)\n", maxKernelIndex -1);
    fprintf(out, "  -i, --iterations <iterations>    number of iterations (1)\n");

    fprintf(out, "\n");
    fprintf(out, "Example: %s before.bmp after.bmp -i 10000\n", exec);
}

int main(int argc, char **argv) {
    MPI_Init(&argc, &argv); //Initialize MPI
    MPI_Comm_size(MPI_COMM_WORLD, &size); //Here we use the globally assigned variables size and rank
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    /*
        Parameter parsing, don't change this!
    */
    unsigned int iterations = 1;
    char *output = NULL;
    char *input = NULL;
    unsigned int kernelIndex = 2;
    int ret = 0;


    if (rank == 0) { //Only rank 0 does the parameter parsing
        static struct option const long_options[] = {
                {"help",       no_argument,       0, 'h'},
                {"kernel",     required_argument, 0, 'k'},
                {"iterations", required_argument, 0, 'i'},
                {0,            0,                 0, 0}
        };

        static char const *short_options = "hk:i:";
        {
              char *endptr;
              int c;
              int parse;
              int option_index = 0;
              while ((c = getopt_long(argc, argv, short_options, long_options, &option_index)) != -1) {
                  switch (c) {
                      case 'h':
                          help(argv[0], 0, NULL);
                          goto graceful_exit;
                      case 'k':
                          parse = strtol(optarg, &endptr, 10);
                          if (endptr == optarg || parse < 0 || parse >= maxKernelIndex) {
                              help(argv[0], c, optarg);
                              goto error_exit;
                          }
                          kernelIndex = (unsigned int) parse;
                          break;
                      case 'i':
                          iterations = strtol(optarg, &endptr, 10);
                          if (endptr == optarg) {
                              help(argv[0], c, optarg);
                              goto error_exit;
                          }
                          break;
                      default:
                          abort();
                  }
              }
          }

          if (argc <= (optind + 1)) {
              help(argv[0], ' ', "Not enough arugments");
              goto error_exit;
          }

          unsigned int arglen = strlen(argv[optind]);
          input = calloc(arglen + 1, sizeof(char));
          strncpy(input, argv[optind], arglen);
          optind++;

          arglen = strlen(argv[optind]);
          output = calloc(arglen + 1, sizeof(char));
          strncpy(output, argv[optind], arglen);
          optind++;
    }
    /*
        End of Parameter parsing!
    */

    /*
        Create the BMP image and load it from disk.
    */
    bmpImage *image = newBmpImage(0,0);
    if (rank == 0) { //Only rank 0 has the image data so thus rank 0 has to create the bmpImage variable
          if (image == NULL) {
              fprintf(stderr, "Could not allocate new image!\n");
              goto error_exit;
          }

          if (loadBmpImage(image, input) != 0) {
              fprintf(stderr, "Could not load bmp image '%s'!\n", input);
              freeBmpImage(image);
              goto error_exit;
          }

          printf("Apply kernel '%s' on image with %u x %u pixels for %u iterations\n", kernelNames[kernelIndex],
                 image->width, image->height, iterations);
    }


    MPI_Barrier(MPI_COMM_WORLD); //Barrier before and after for most precise time measurement
    // TODO: implement time measurement from here
    //clock_t t = clock(); //For serial
    double start_time, end_time;
    if(rank == 0) { //Only rank 0 does the time measurement
        start_time = MPI_Wtime(); //I used MPI_Wtime(); to get the current time
    }
    MPI_Barrier(MPI_COMM_WORLD);
    // Here we do the actual computation!
    // image->data is a 2-dimensional array of pixel which is accessed row first ([y][x])
    // each pixel is a struct of 3 unsigned char for the red, blue and green colour channel

    if(size > 1) {
        int image_height = image->height; //Decleare global variables to be broadcasted
        int image_width = image->width;
        MPI_Bcast(&iterations, 1, MPI_INT, 0, MPI_COMM_WORLD); //Broadcasting them from rank 0 to all ranks as only rank 0 has the data from parsing the parameters
        MPI_Bcast(&kernelIndex, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&image_height, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&image_width, 1, MPI_INT, 0, MPI_COMM_WORLD);


        int *local_heights = (int*) calloc(size*sizeof(int), 1); //Local heights is an array of number of local rows for each rank, here set to zero
        int local_height; //This is the maximum number of local rows a rank can posess
        int n; //n is the index of the first rank which does not have local_height number of rows
        int end; //end is the index of the last rank with non zero number of rows (a rather extreme edge case perhaps)
        if(image_height%size != 0) { //If total number of rows don't add up with number of ranks:
              local_height = image_height/size +1; //The first ranks will have local_height number of local_rows
              n = image_height/local_height; //The n first ranks will have this height
              for(int i = 0; i < n; i++) {
                  local_heights[i] = local_height; //Fill in that height for the n first ranks
              }
              int end_height = image_height - n*local_height; // The last nonzero height will be will have end_height number of local rows
              local_heights[n] = end_height; //Insert this height for the last rank with nonzero height
              if(end_height != 0) { //If the last height is nonzero this will be the rank with the last nonzero height
                  end = n;
              } else { //If the end_height is zero the last nonzero height belongs to n-1
                  end = n-1;
              }
        } else { //If number of rows do add up with number of ranks
              local_height = image_height/size; //All ranks will have the same number of local_rows called local_height
              n = size; //All size ranks will have this height
              end = size-1; //The last nonzero height is rank size
              for(int i = 0; i < size; i++) {
                  local_heights[i] = local_height; //Assign local_height for all ranks
              }
        }

        pixel *pixels = NULL;
        if(rank == 0) { //Here rank 0 creates a single array of pixels to be scattered
              pixels = (pixel*) calloc(sizeof(pixel)*image_width*size*local_height, 1);  //Allocating at least the maximum number of rows to every rank
              for(int i = 0; i < image_height; i++) {
                  for(int j = 0; j<image_width; j++) {
                      pixels[i*image_width + j] = image->data[i][j];
                  }
              }
        }

        pixel *local_rows = (pixel*) calloc(sizeof(pixel)*image_width*local_height, 1); //These are the local rows to be scattered to
        MPI_Scatter(pixels, sizeof(pixel)*image_width*local_height, MPI_CHAR, local_rows, sizeof(pixel)*image_width*local_height, MPI_CHAR, 0, MPI_COMM_WORLD); //Here we scatter chunks of rows with pixels from rank 0 to the ranks

        int boundary_height = kernelDims[kernelIndex]/2; //This is the number of rows to be sent between ranks (This case assumes the local rows aren't fewer than the boundary rows needed to be shared, i.e. no rank has to send to rank+-2)
        int boundary_size = sizeof(pixel) * image_width * boundary_height; //This is the size of the boundary data to be sent
        pixel *upper_boundary = (pixel*) calloc(boundary_size, 1); //This is memory allocated for the local boundary to be recieved from above
        pixel *lower_boundary = (pixel*) calloc(boundary_size, 1); //This is memory allocated for the local boundary to be recieved from above

        pixel *temp_local_rows = (pixel*)calloc(sizeof(pixel) * image_width * local_height, 1); //This is a temporary buffer used for swapping images for each iteration

        if (local_heights[rank] != 0) { //If the rank has rows
            for (int i=0; i<iterations; i++) { //Do for iterations times
                MPI_Barrier(MPI_COMM_WORLD); //Here a barrier is put to reduce buffering when ranks send boundaries
                pixel *start_adress = &(local_rows[image_width * (local_heights[rank]-boundary_height)]); //Important to update where this pointer points to after swapping

                if (rank != 0 && rank < end) { //If rank is not 0 or end
                    MPI_Sendrecv(local_rows, boundary_size, MPI_CHAR, rank-1, rank*2+1, //send upper row(s) up, receive upper boundary from above
                                 upper_boundary, boundary_size, MPI_CHAR, rank-1, (rank-1)*2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    MPI_Sendrecv(start_adress, boundary_size, MPI_CHAR, rank+1, rank*2, //send lower row(s) down, receive lower boundary from below
                                 lower_boundary, boundary_size, MPI_CHAR, rank+1, (rank+1)*2+1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

                } else if (rank == 0) { //If rank is 0
                    MPI_Sendrecv(start_adress, boundary_size, MPI_CHAR, rank+1, rank*2, //send lower row(s) down, receive lower boundary from below
                                 lower_boundary, boundary_size, MPI_CHAR, rank+1, (rank+1)*2+1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

                } else { //If rank is end
                    MPI_Sendrecv(local_rows, boundary_size, MPI_CHAR, rank-1, rank*2+1, //send upper row(s) up, receive upper boundary from above
                                 upper_boundary, boundary_size, MPI_CHAR, rank-1, (rank-1)*2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

                }
            applyKernelReplica(temp_local_rows, upper_boundary, local_rows, lower_boundary, image_width, //Apply convolution to the local rows, with access to boundaries
                               kernels[kernelIndex], kernelDims[kernelIndex], kernelFactors[kernelIndex], local_heights[rank]);

            MPI_Barrier(MPI_COMM_WORLD); //Wait for all ranks to write new data before swapping pointers

            pixel *temp = temp_local_rows; //Setting the pointer to a new array so the old values can be
            temp_local_rows = local_rows;
            local_rows = temp;
            }
        } else { //If a rank has no rows (again, a bit extreme edge case)
            for (int i=0; i<iterations; i++) {
                MPI_Barrier(MPI_COMM_WORLD); //but these ranks has to reach the barriers too
                MPI_Barrier(MPI_COMM_WORLD);
            }
        }


        //All chunks of rows are gathered back again to rank 0
        MPI_Gather(local_rows, sizeof(pixel)*image_width*local_height, MPI_CHAR, pixels, sizeof(pixel)*image_width*local_height, MPI_CHAR, 0, MPI_COMM_WORLD);
        if(rank == 0) { //And then the image is copied back from a singe array to a matrix
            for(int i=0; i < image_height; i++) {
                for(int j=0; j < image_width; j++) {
                    image->data[i][j] = pixels[i*image_width + j];
                }
            }
        }

        if (rank == 0) { //Free up arrays
            free(pixels);
        }
        free(local_rows);
        free(upper_boundary);
        free(lower_boundary);
        free(local_heights);
        free(temp_local_rows);


    } else {//If size == 1, just use the serial function
        bmpImage *processImage = newBmpImage(image->width, image->height);
        for (unsigned int i = 0; i < iterations; i ++) {
            applyKernel(processImage->data,
                        image->data,
                        image->width,
                        image->height,
                        kernels[kernelIndex],
                        kernelDims[kernelIndex],
                        kernelFactors[kernelIndex]
            );
            swapImage(&processImage, &image);
        }
        freeBmpImage(processImage);
    }

    MPI_Barrier(MPI_COMM_WORLD); //Make sure all ranks reach the end time at the same time
    if(rank == 0) { //Rank 0 measures the end time
        // TODO: implement time measurement to here
        end_time = MPI_Wtime();
        double spentTime = end_time - start_time; //Total time spent at the parallel part

        //t = clock()-t; //For serial
        //double spentTime = ((float)t)/CLOCKS_PER_SEC;
        printf("Time spent: %.3f seconds\n", spentTime);
        //Write the image back to disk
        if (saveBmpImage(image, output) != 0) {
            fprintf(stderr, "Could not save output to '%s'!\n", output);
            freeBmpImage(image);
            goto error_exit;
        };
    }

    MPI_Finalize(); //End of parallel code

  graceful_exit:
    ret = 0;
  error_exit:
    if (input)
        free(input);
    if (output)
        free(output);
    return ret;
};
