#include <stdlib.h>
#include <stdio.h>
#include "bitmap.h"

// save 24-bits bmp file, buffer must be in bmp format: upside-down
void savebmp(char *name,uchar *buffer,int x,int y) {
	FILE *f=fopen(name,"wb");
	if(!f) {
		printf("Error writing image to disk.\n");
		return;
	}
	unsigned int size=x*y*3+54;
	uchar header[54]={'B','M',size&255,(size>>8)&255,(size>>16)&255,size>>24,0,
                    0,0,0,54,0,0,0,40,0,0,0,x&255,x>>8,0,0,y&255,y>>8,0,0,1,0,24,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	fwrite(header,1,54,f);
	fwrite(buffer,1,x*y*3,f);
	fclose(f);
}

// read bmp file and store image in contiguous array
void readbmp(char* filename, uchar* array) {
	FILE* img = fopen(filename, "rb");   //read the file
	uchar header[54];
	fread(header, sizeof(uchar), 54, img); // read the 54-byte header

  // extract image height and width from header
	int width = *(int*)&header[18];
	int height = *(int*)&header[22];
	int padding=0;
	while ((width*3+padding) % 4!=0) padding++;

	printf("Test width = %d and height = %d \n", width, height);

	int widthnew=width*3+padding;
	uchar* data = calloc(widthnew, sizeof(uchar));

	for (int i=0; i<height; i++ ) {
		fread( data, sizeof(uchar), widthnew, img);
		for (int j=0; j<width*3; j+=3) {
			array[3 * i * width + j + 0] = data[j+0];
			array[3 * i * width + j + 1] = data[j+1];
			array[3 * i * width + j + 2] = data[j+2];
		}
	}
	fclose(img); //close the file
}

void inverseColour(uchar *array, int length) { // Ads 120 to every colour and making sure it doesnt exceed 256 by modulo
    for (int i = 0; i < length; i++) {
        array[i] += 128;
        array[i] = array[i]%256;
    }
}

void resolutionEnchancer(uchar *arrayOld, uchar *arrayNew, int XSIZE, int YSIZE) {
    int ind1;
    int ind2;
    int XNEW = 2*XSIZE;
    printf("%d", XNEW);
    for (int i = 0; i < YSIZE; i++) { // First the old values are placed with one empty cell between each
        for (int j = 0; j < XSIZE; j++) {
            ind1 = 3*(2*i*XNEW + 2*j);
            ind2 = 3*(i*XSIZE + j);
            arrayNew[ind1] = arrayOld[ind2];
            arrayNew[ind1+1] = arrayOld[ind2+1];
            arrayNew[ind1+2] = arrayOld[ind2+2];
        }
    }
    for (int i = 0; i < YSIZE; i++) { // Then the cells horizontally between the old values are interpolated
        for (int j = 0; j < XSIZE-1; j++) {
            ind1 = 3*(2*i*XNEW + 2*j+1);
            arrayNew[ind1] = 0.5*(arrayNew[ind1-3]+arrayNew[ind1+3]);
            arrayNew[ind1+1] = 0.5*(arrayNew[ind1-2]+arrayNew[ind1+4]);
            arrayNew[ind1+2] = 0.5*(arrayNew[ind1-1]+arrayNew[ind1+5]);
        }
    }
    for (int i = 0; i < YSIZE-1; i++) { // Finally the empty rows are interpolated from values below and above
        for (int j = 0; j < XNEW; j++) {
            ind1 = 3*((2*i+1)*XNEW + j);
            arrayNew[ind1] = 0.5*(arrayNew[ind1-XNEW*3] + arrayNew[ind1+XNEW*3]);
            arrayNew[ind1+1] = 0.5*(arrayNew[ind1-XNEW*3+1] + arrayNew[ind1+XNEW*3+1]);
            arrayNew[ind1+2] = 0.5*(arrayNew[ind1-XNEW*3+2] + arrayNew[ind1+XNEW*3+2]);
        }
    }
}