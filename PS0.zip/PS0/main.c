#include <stdlib.h>
#include <stdio.h>
#include "bitmap.h"

#define XSIZE 2560 // Size of before image
#define YSIZE 2048

int main() {
	uchar *image = calloc(XSIZE * YSIZE * 3, 1); // Three uchars per pixel (RGB)
	readbmp("before.bmp", image);
	// Alter the image here
    int length = XSIZE*YSIZE*3;
    inverseColour(image, length);
    uchar *image2 = calloc(XSIZE*YSIZE * 3*4, 1);
    resolutionEnchancer(image, image2, XSIZE, YSIZE);
	savebmp("after.bmp", image2, 2*XSIZE, 2*YSIZE);
	free(image);
	return 0;
}
